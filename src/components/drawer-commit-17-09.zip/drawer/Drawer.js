/*
* Licensed Materials - Property of IBM
* 5724-Q36
* (c) Copyright IBM Corp. 2016, 2017
* US Government Users Restricted Rights - Use, duplication or disclosure
* restricted by GSA ADP Schedule Contract with IBM Corp.
*/

import React, { Component, PropTypes } from 'react';
import { Icon } from 'ap-components-react';
import drawerStyles from './drawer.scss';

export default class Drawer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
    };
    this.toggleDrawer = this.toggleDrawer.bind(this);
  }

  // sets the width that comes as props
  getDrawerSize() {
    let drawerStyle;
    let { width, height } = this.props;

  // Updating Height and Width props for appending em or px if not provided
    if (typeof width === 'string' && width.indexOf('em') === -1 && width.indexOf('px') === -1) {
      width = `${width}em`;
    }
    if (typeof height === 'string' && height.indexOf('em') === -1 && height.indexOf('px') === -1) {
      height = `${height}em`;
    }

    if (this.props.position === 'Right') {
      drawerStyle = this.state.isOpen ? { width, height } : { height };
    } else if (this.props.position === 'Left') {
      drawerStyle = this.state.isOpen ? { marginLeft: `-${width}`, width, height } : { };
    } else if (this.props.position === 'Up') {
      drawerStyle = this.state.isOpen ? { marginTop: `-${height}`, height, width } : { width };
    } else if (this.props.position === 'Down') {
      drawerStyle = this.state.isOpen ? { marginBottom: `-${height}`, height, width } : { width };
    }
    return drawerStyle;
  }
  // sets the size for icon
  getIconSize() {
    let { iconSize } = this.props;
    if (typeof iconSize === 'string' && iconSize.indexOf('em') === -1 && iconSize.indexOf('px') === -1) {
      iconSize = `${iconSize}em`;
    }
    return iconSize;
  }

  // toggles the opening and closing of drawer
  toggleDrawer() {
    this.setState({
      isOpen: !this.state.isOpen,
    });
  }

  render() {
    let className = '';
    className = this.state.isOpen ? `openDrawer${this.props.position}` : `closeDrawer${this.props.position}`;

    return (<div
      id={this.props.id || ''}
      className={`${drawerStyles.container} 
        ${this.props.classNameDrawer || ''}
        `}
      style={this.props.style || {}}
    >
      <div
        role="presentation"
        onClick={this.toggleDrawer}
      >
        <Icon type={this.state.isOpen ? 'close' : 'plus'} size={this.getIconSize()}></Icon>
      </div>
      <div
        style={this.getDrawerSize()}
        className={
          `
            ${drawerStyles.pannel}
            ${drawerStyles[this.props.position.toLowerCase()]}
            ${drawerStyles[className]}
          `
        }
      >
        {this.props.children}
      </div>
    </div>
    );
  }
}

Drawer.propTypes = {
  id: PropTypes.string,  // Sets the id | optional
  position: PropTypes.oneOf(['Up', 'Left', 'Down', 'Right']), // Set the opening and closing of drawer | optional
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]), // Set the width sent by the user | optional
  height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]), // Set the height sent by the user | optional
  children: PropTypes.node,  // Set the appropriate children | optional.
  classNameDrawer: PropTypes.string,  // Sets additional stylings for the drawer | optional.
  style: PropTypes.object, // Sets additional style as per users requirement
  iconSize: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]), // Size of the drawer icon | optional.
};

Drawer.defaultProps = {
  position: 'Right',
  iconSize: '2em',
  width: '100px',
  height: '2em',
};
