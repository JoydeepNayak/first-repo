 /*
* Licensed Materials - Property of IBM
* 5724-Q36
* (c) Copyright IBM Corp. 2016, 2017
* US Government Users Restricted Rights - Use, duplication or disclosure
* restricted by GSA ADP Schedule Contract with IBM Corp.
*/

import React from 'react';
import { shallow } from 'enzyme';
import Drawer from '../Drawer';

describe('Drawer Component Testing (<Drawer />)', () => {
  let wrapper;
  let wrapperProps;
  let props;

  beforeEach(() => {
    props = {
      position: 'Left',
      size: '2',
      classNameDrawer: 'abc',
      width: '400px',
    };
    wrapper = shallow(<Drawer />);
    wrapperProps = shallow(<Drawer {...props} />);
  });
  it('1-Must render Drawer component ', () => {
    expect(wrapperProps.instance()).toBeInstanceOf(Drawer);
  });
  it('2-Must render Drawer component ', () => {
    expect(wrapper.instance()).toBeInstanceOf(Drawer);
  });
  it('3-Must toggle the isOpen value ', () => {
    wrapperProps.instance().toggleDrawer();
    expect(wrapperProps.instance().state.isOpen).toBe(true);
  });
  it('4-Drawer comoponet with Right and width props ', () => {
    const props1 = {
      position: 'Right',
      classNameDrawer: 'abc',
      width: '400',
    };
    const wrapper2 = shallow(<Drawer {...props1} />);
    expect(wrapper2.instance().getDrawerSize().height).toBe('100px');
  });
  it('5-Drawer comoponet with Down props ', () => {
    const props1 = {
      position: 'Down',
      classNameDrawer: 'abc',
      height: '400',
    };
    const wrapper2 = shallow(<Drawer {...props1} />);
    expect(wrapper2.instance().getDrawerSize().width).toBe('100px');
  });
  it('6-Drawer comoponet with Up props ', () => {
    const props1 = {
      position: 'Up',
      classNameDrawer: 'abc',
      height: '400',
    };
    const wrapper2 = shallow(<Drawer {...props1} />);
    expect(wrapper2.instance().getDrawerSize().width).toBe('100px');
  });
});
