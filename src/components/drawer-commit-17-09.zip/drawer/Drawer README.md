# Drawer
Allows the user to open and close a drawer in left, right, top and  bottom directions.

#### Usage
For a developer to access drawer. Following steps are required -

1) Import  Drawer from gov-shared-ui -> `import Drawer from '@infoserver/gov-shared-ui/src/components/drawer/Drawer';`

   | Prop name | Type | isRequired | Comments |
   |   :---: | :---: | :---: | :---  |
   | id| String| No| Sets the id |
   | position| String | No | Sets the opening and closing of drawer|
   | width| String/ Number | No |  Sets the width of the drawer sent by the user|
   | height| String/ Number | No |  Sets the height of the drawer sent by the user|
   | children|node|No|Set the appropriate children|
   | classNameDrawer|String |No|Sets additional stylings for the drawer|
   | style|Object|No|Sets additional style as per usage|
   | iconSize |String/ Number|No|Size of the drawer icon|

#### Example
````
import Drawer from '@infoserver/gov-shared-ui/src/components/drawer/Drawer;'

...

        <Drawer position="Down" size="3em" width="3em" height="3em">
          <p>OPENS</p>
        </Drawer>
````
